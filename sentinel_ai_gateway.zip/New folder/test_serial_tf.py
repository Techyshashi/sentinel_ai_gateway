# test_serial_tf.py
"""
Serial TF client + Digital Twin poster.

- Reads serial lines from Arduino
- Builds rolling window (SEQ_LEN) for model
- Normalizes, runs TF model inference (expect model in model_tf/)
- Determines SAFE/WARNING/CRITICAL
- Posts JSON to local twin at http://localhost:5000/update
"""

import serial, re, time, json
import numpy as np
import requests
from collections import deque
from model_utils_tf import load_model

# ----- CONFIG -----
PORT = "COM7"           # << change to your COM port
BAUD = 115200
TWIN_URL = "http://localhost:5000/update"
THRESHOLD = 0.5
WARNING_TIME = 2.0
CRITICAL_TIME = 5.0
# ------------------

RE_NUMBER = re.compile(r"[-+]?\d*\.\d+|\d+")

def extract_numbers(line):
    nums = RE_NUMBER.findall(line)
    return [float(x) for x in nums] if len(nums) >= 3 else None

def main():
    model, mu, sigma, SEQ_LEN = load_model("model_tf")
    mu = np.array(mu)
    sigma = np.array(sigma)

    ser = serial.Serial(PORT, BAUD, timeout=1)
    print(f"Listening on {PORT} @ {BAUD} - using sequence length {SEQ_LEN}")

    buffer = deque(maxlen=SEQ_LEN)
    warn_start = None
    crit_start = None

    while True:
        try:
            raw = ser.readline().decode("utf-8", errors="ignore").strip()
            if not raw:
                continue
            nums = extract_numbers(raw)
            if nums is None:
                print("Invalid:", raw)
                continue

            rms, kurt, temp = nums[-3], nums[-2], nums[-1]
            buffer.append([rms, kurt, temp])

            if len(buffer) < SEQ_LEN:
                print(f"Buffering {len(buffer)}/{SEQ_LEN}", end="\r")
                continue

            seq = np.array(buffer, dtype=np.float32)
            seq = (seq - mu) / (sigma + 1e-9)
            seq_batch = np.expand_dims(seq, axis=0)
            prob = float(model(seq_batch).numpy()[0][0])

            now = time.time()
            # decide state
            if prob > THRESHOLD:
                if warn_start is None:
                    warn_start = now
                    crit_start = now
                elapsed = now - warn_start
                if elapsed >= CRITICAL_TIME:
                    state = "CRITICAL"
                elif elapsed >= WARNING_TIME:
                    state = "WARNING"
                else:
                    state = "WARNING"
            else:
                warn_start = None
                crit_start = None
                state = "SAFE"

            print(f"[{state}] P={prob:.3f} RMS={rms:.5f} Kurt={kurt:.3f} Temp={temp:.2f}")

            # build packet and POST to twin
            packet = {
                "timestamp_ms": int(now*1000),
                "prob_failure": prob,
                "rms": float(rms),
                "kurtosis": float(kurt),
                "temperature": float(temp),
                "state": state
            }
            try:
                resp = requests.post(TWIN_URL, json=packet, timeout=0.5)
                # optional: check resp.status_code
            except Exception as e:
                print("Twin post error:", e)

        except KeyboardInterrupt:
            print("Stopped by user.")
            break
        except Exception as e:
            print("Error:", e)

if __name__ == "__main__":
    main()