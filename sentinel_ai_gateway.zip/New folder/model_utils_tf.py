# model_utils_tf.py
import tensorflow as tf
import numpy as np
import json
import os

# ------------------------------------------
# Build a clean, simple Sequential LSTM model
# ------------------------------------------
def build_model(seq_len, n_features=3, hidden=64):

    model = tf.keras.Sequential([
        tf.keras.layers.Input(shape=(seq_len, n_features)),
        tf.keras.layers.LSTM(hidden, return_sequences=False),
        tf.keras.layers.Dense(32, activation='relu'),
        tf.keras.layers.Dense(1, activation='sigmoid')
    ])

    return model


# ------------------------------------------
# Save model + normalization stats
# ------------------------------------------
def save_model(model, mu, sigma, seq_len, path="model_tf"):
    os.makedirs(path, exist_ok=True)

    # Save keras model
    model.save(os.path.join(path, "model.h5"))

    # Save meta info
    meta = {
        "mu": mu.tolist(),
        "sigma": sigma.tolist(),
        "seq_len": seq_len
    }

    with open(os.path.join(path, "meta.json"), "w") as f:
        json.dump(meta, f, indent=4)

    print("[OK] Model + metadata saved.")


# ------------------------------------------
# Load model + normalization stats
# ------------------------------------------
def load_model(path="model_tf"):

    model = tf.keras.models.load_model(os.path.join(path, "model.h5"))

    with open(os.path.join(path, "meta.json"), "r") as f:
        meta = json.load(f)

    mu = np.asarray(meta["mu"])
    sigma = np.asarray(meta["sigma"])
    seq_len = meta["seq_len"]

    print("[OK] Model + metadata loaded.")
    return model, mu, sigma, seq_len