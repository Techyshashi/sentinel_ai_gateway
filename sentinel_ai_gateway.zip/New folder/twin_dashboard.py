# twin_dashboard.py
import streamlit as st
import requests
import time
import pandas as pd

TWIN_STATE_URL = "http://localhost:5000/state"
TWIN_HISTORY_URL = "http://localhost:5000/history?n=200"

st.set_page_config(page_title="Sentinel AI Gateway", layout="wide")
st.title("Cognitive Digital Twin — System Health Status (SAFE / WARNING / CRITICAL)")

col1, col2 = st.columns([2,1])

with col1:
    st.header("Live telemetry")
    placeholder = st.empty()
    chart = st.empty()

with col2:
    st.header("Twin summary")
    latest_box = st.empty()
    counts_box = st.empty()
    refresh = st.button("Refresh now")

def fetch_state():
    try:
        r = requests.get(TWIN_STATE_URL, timeout=1.0)
        if r.status_code == 200:
            return r.json()
    except:
        return None

def fetch_history():
    try:
        r = requests.get(TWIN_HISTORY_URL, timeout=1.0)
        if r.status_code == 200:
            return r.json()
    except:
        return None

# Main loop - update every 1s
while True:
    st.experimental_rerun() if refresh else None
    state = fetch_state()
    hist = fetch_history()

    if state is None:
        placeholder.warning("Twin not available at http://localhost:5000. Start local_twin.py and test_serial_tf.py")
        time.sleep(1.0)
        continue

    latest = state.get("latest", {})
    counts = state.get("counts", {})

    latest_box.subheader("Latest State")
    latest_box.json(latest)

    counts_box.subheader("State counts (recent history)")
    counts_box.write(counts)

    # Build DataFrame for chart
    if hist:
        df = pd.DataFrame(hist)
        df['t'] = pd.to_datetime(df['timestamp_ms'], unit='ms')
        df = df.sort_values('t')
        df = df.set_index('t')
        chart.line_chart(df[['prob_failure','rms','kurtosis','temperature']])
    else:
        chart.info("No history yet.")

    time.sleep(1.0)