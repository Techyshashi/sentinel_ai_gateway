# train_tf.py
import numpy as np
import pandas as pd
import tensorflow as tf
from model_utils_tf import build_model, save_model

SEQ_LEN = 128
OVERLAP = 0.5

# -------------------------
# Load your dataset
# -------------------------
df = pd.read_csv("synthetic_dataset.csv")

X = df[["rms_g", "kurtosis", "temp_C"]].values.astype(np.float32)
y = df["label"].values.astype(np.float32)

# -------------------------
# Make sequences
# -------------------------
def make_sequences(X, y, seq_len=128, overlap=0.5):
    xs, ys = [], []
    step = int(seq_len * (1 - overlap))

    for i in range(0, len(X) - seq_len, step):
        xs.append(X[i:i+seq_len])
        ys.append(int(y[i:i+seq_len].mean() > 0.5))

    return np.array(xs, dtype=np.float32), np.array(ys, dtype=np.float32)

X_seq, y_seq = make_sequences(X, y, SEQ_LEN, OVERLAP)

print("[INFO] Sequence dataset:", X_seq.shape, y_seq.shape)

# -------------------------
# Train / val split
# -------------------------
split = int(0.8 * len(X_seq))
X_train, X_val = X_seq[:split], X_seq[split:]
y_train, y_val = y_seq[:split], y_seq[split:]

# -------------------------
# Compute normalization stats
# -------------------------
mu = X_train.mean(axis=(0, 1))
sigma = X_train.std(axis=(0, 1)) + 1e-9

X_train = (X_train - mu) / sigma
X_val   = (X_val   - mu) / sigma

# -------------------------
# Build model
# -------------------------
model = build_model(SEQ_LEN, n_features=3)

model.compile(
    optimizer=tf.keras.optimizers.Adam(1e-3),
    loss="binary_crossentropy",
    metrics=["accuracy"]
)

# -------------------------
# Train
# -------------------------
history = model.fit(
    X_train, y_train,
    validation_data=(X_val, y_val),
    epochs=15,
    batch_size=32,
    verbose=1
)

# -------------------------
# Save model + stats
# -------------------------
save_model(model, mu, sigma, SEQ_LEN, path="model_tf")