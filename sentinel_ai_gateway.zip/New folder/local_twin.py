# local_twin.py
"""
Simple Local Digital Twin HTTP engine.

Run:
    python local_twin.py

Endpoints:
  POST /update    -> accepts JSON packet (machine telemetry)
  GET  /state     -> returns latest summary JSON
  GET  /history   -> returns recent history (last N entries)

This keeps everything in memory (deque). It also appends to local CSV "twin_log.csv".
"""
from flask import Flask, request, jsonify
from collections import deque
import time
import threading
import csv
from pathlib import Path

app = Flask(__name__)

# keep last N datapoints
MAX_HISTORY = 2000
history = deque(maxlen=MAX_HISTORY)
lock = threading.Lock()
LOG_CSV = "twin_log.csv"

# ensure CSV header
hdr_written = False
if not Path(LOG_CSV).exists():
    with open(LOG_CSV, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["timestamp_ms","state","prob_failure","rms","kurtosis","temperature"])

@app.route("/update", methods=["POST"])
def update():
    """Receive JSON telemetry and add to twin history."""
    global hdr_written
    data = request.get_json(force=True)
    # Expected keys: timestamp_ms, prob_failure, rms, kurtosis, temperature, state
    now = int(time.time() * 1000)
    packet = {
        "received_ms": now,
        "timestamp_ms": data.get("timestamp_ms", now),
        "prob_failure": float(data.get("prob_failure", 0.0)),
        "rms": float(data.get("rms", 0.0)),
        "kurtosis": float(data.get("kurtosis", 0.0)),
        "temperature": float(data.get("temperature", 0.0)),
        "state": data.get("state", "UNKNOWN")
    }
    with lock:
        history.append(packet)
        # append to CSV
        with open(LOG_CSV, "a", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([packet["timestamp_ms"], packet["state"], packet["prob_failure"],
                             packet["rms"], packet["kurtosis"], packet["temperature"]])
    return jsonify({"status":"ok"}), 200

@app.route("/state", methods=["GET"])
def state():
    """Return latest summary: last state and counts."""
    with lock:
        if not history:
            return jsonify({"status":"empty"})
        latest = history[-1]
        # simple counts
        counts = {"SAFE":0, "WARNING":0, "CRITICAL":0, "UNKNOWN":0}
        for p in history:
            counts[p["state"]] = counts.get(p["state"],0) + 1
        summary = {
            "latest": latest,
            "counts": counts,
            "history_len": len(history)
        }
    return jsonify(summary), 200

@app.route("/history", methods=["GET"])
def get_history():
    """Return recent history (optionally ?n=100)."""
    n = int(request.args.get("n", 200))
    with lock:
        data = list(history)[-n:]
    return jsonify(data), 200

if __name__ == "__main__":
    print("Starting Local Digital Twin on http://0.0.0.0:5000")
    app.run(host="0.0.0.0", port=5000, debug=False)